<?php

namespace App\Models;

use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;

class Ship extends Model
{
    protected $hidden = [];
    protected $table = 'ships';
}
