<?php

namespace App\Models;

use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;

class CargoItem extends Model
{
    protected $hidden = [];
    protected $table = 'cargo_items';
}
